import java.rmi.*;
import java.math.BigInteger;

public interface AddServerIntf extends Remote {
    // Method declaration
    BigInteger fct(int d1) throws RemoteException;
}
