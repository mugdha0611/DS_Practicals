import java.rmi.*;
import java.rmi.server.*;
import java.math.BigInteger;

// Class that implements the remote interface
public class AddServerImpl extends UnicastRemoteObject implements AddServerIntf {

    // Constructor
    public AddServerImpl() throws RemoteException {
    }

    // Implement method declared in the interface
    public BigInteger fct(int c) throws RemoteException {
        BigInteger fact = BigInteger.ONE;
        for (int i = 1; i <= c; i++) {
            fact = fact.multiply(BigInteger.valueOf(i));
        }
        return fact;
    }
}
