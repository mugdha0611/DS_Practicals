import java.rmi.*;

public class AddClient {
    public static void main(String args[]) {
        try {
            // Get reference to the remote object
            String addServerURL = "rmi://" + args[0] + "/AddServer";
            AddServerIntf addServerIntf = (AddServerIntf) Naming.lookup(addServerURL);

            // Combine all arguments from args[1] onward
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i < args.length; i++) {
                sb.append(args[i]);
                if (i != args.length - 1) {
                    sb.append(" "); // Add space between words
                }
            }
            String sentence = sb.toString();

            System.out.println("Your Name is : " + sentence);
            System.out.println(":) " + addServerIntf.hel(sentence));
        }
        catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}
