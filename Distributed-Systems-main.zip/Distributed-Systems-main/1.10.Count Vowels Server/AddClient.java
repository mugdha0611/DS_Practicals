import java.rmi.*;

public class AddClient {
    public static void main(String args[]) {
        try {
            // Get reference to the remote object
            String addServerURL = "rmi://" + args[0] + "/AddServer";
            AddServerIntf addServerIntf = (AddServerIntf) Naming.lookup(addServerURL);

            // Join all args after args[0] into one sentence
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i < args.length; i++) {
                sb.append(args[i]);
                if (i != args.length - 1) {
                    sb.append(" "); // add space between words
                }
            }
            String sentence = sb.toString();

            System.out.println("The String: " + sentence);
            System.out.println("Count of Vowels : " + addServerIntf.cvwl(sentence));
        }
        catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}
