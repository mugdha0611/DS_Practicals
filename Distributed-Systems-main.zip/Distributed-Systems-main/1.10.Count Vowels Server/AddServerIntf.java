import java.rmi.*;
public interface AddServerIntf extends Remote { 
//method declaration 
int cvwl(String d1) throws RemoteException;
}
