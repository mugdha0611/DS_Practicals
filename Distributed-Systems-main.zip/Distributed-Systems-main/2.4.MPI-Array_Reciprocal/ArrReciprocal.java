import mpi.*;
import java.util.Random;

public class ArrReciprocal {
    public static void main(String[] args) throws Exception {
        MPI.Init(args);

        int rank = MPI.COMM_WORLD.Rank();
        int size = MPI.COMM_WORLD.Size();
        int root = 0;

        double send_buffer[] = new double[size];
        double recv_buffer[] = new double[1];
        double result_buffer[] = new double[size];

        // Initialize data at root
        if (rank == root) {
            Random rand = new Random();
            System.out.println("Original Array:");
            for (int i = 0; i < size; i++) {
                send_buffer[i] = rand.nextInt(10) + 1; // random numbers from 1 to 10 (avoid divide by zero)
                System.out.println("Element " + i + " = " + send_buffer[i]);
            }
        }

        // Scatter: Each process gets 1 element
        MPI.COMM_WORLD.Scatter(
            send_buffer, 0, 1, MPI.DOUBLE,
            recv_buffer, 0, 1, MPI.DOUBLE,
            root
        );

        // Each worker calculates reciprocal
        recv_buffer[0] = 1.0 / recv_buffer[0];

        // Gather all reciprocals back to root
        MPI.COMM_WORLD.Gather(
            recv_buffer, 0, 1, MPI.DOUBLE,
            result_buffer, 0, 1, MPI.DOUBLE,
            root
        );

        // Root displays the final array
        if (rank == root) {
            System.out.println("\nReciprocal Array:");
            for (int i = 0; i < size; i++) {
                System.out.println("Reciprocal of element " + i + " = " + result_buffer[i]);
            }
        }

        MPI.Finalize();
    }
}
