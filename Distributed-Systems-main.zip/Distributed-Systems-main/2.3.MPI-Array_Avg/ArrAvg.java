import java.util.Scanner;
import java.util.Random;
import mpi.*;

public class ArrAvg {
    public static void main(String[] args) throws Exception {
        MPI.Init(args);
        
        int rank = MPI.COMM_WORLD.Rank();
        int size = MPI.COMM_WORLD.Size();
        
        int unitsize = 5;
        int root = 0;
        int send_buffer[] = null;
        send_buffer = new int[unitsize * size];
        int recieve_buffer[] = new int[unitsize];
        double new_recieve_buffer[] = new double[size];

        // Set data for distribution
        if (rank == root) {
            Random rand = new Random();
            int total_elements = unitsize * size;
            System.out.println("Generated " + total_elements + " random elements:");
            for (int i = 0; i < total_elements; i++) {
                send_buffer[i] = rand.nextInt(100); // random number between 0-99
                System.out.println("Element " + i + "\t= " + send_buffer[i]);
            }
        }

        // Scatter data to processes
        MPI.COMM_WORLD.Scatter(
            send_buffer,
            0,
            unitsize,
            MPI.INT,
            recieve_buffer,
            0,
            unitsize,
            MPI.INT,
            root
        );

        // Calculate average at each process
        double local_sum = 0;
        for (int i = 0; i < unitsize; i++) {
            local_sum += recieve_buffer[i];
        }
        double local_avg = local_sum / unitsize;
        
        System.out.println(
            "Intermediate average at process " + rank + " is " + local_avg
        );

        // Gather local averages to root process
        MPI.COMM_WORLD.Gather(
            new double[]{local_avg},
            0,
            1,
            MPI.DOUBLE,
            new_recieve_buffer,
            0,
            1,
            MPI.DOUBLE,
            root
        );

        // Aggregate final average at root
        if (rank == root) {
            double total_avg = 0;
            for (int i = 0; i < size; i++) {
                total_avg += new_recieve_buffer[i];
            }
            total_avg /= size;
            System.out.println("Final average : " + total_avg);
        }

        MPI.Finalize();
    }
}
